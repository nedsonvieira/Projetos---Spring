package br.com.nedson.ScreenMatchComSpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScreenMatchComSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
