package br.com.nedson.UsandoApiFipe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UsandoApiFipeApplication {

	public static void main(String[] args) {
		SpringApplication.run(UsandoApiFipeApplication.class, args);
	}

}
